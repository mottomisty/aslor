<?php
session_start();
include 'db_connect.php'; // Include your database connection

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute
    $stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_password);
        $stmt->fetch();
        if (password_verify($password, $db_password)) {
            $_SESSION['email'] = $email; // Store email in session
            header("Location: dashboard.php"); // Redirect to a dashboard or home page
            exit();
        } else {
            $message = "Incorrect password.";
        }
    } else {
        $message = "Email not found.";
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Rolsa Technologies</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Rolsa Technologies Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="consultation.html">Schedule Consultation</a></li>
                <li><a href="calculator.html">Carbon Footprint Calculator</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h1>Login</h1>
        <form method="POST" action="">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <?php if ($message) echo "<p>$message</p>"; ?>
    </main>
    
    <footer>
        <p>&copy; 2025 Rolsa Technologies</p>
    </footer>
</body>
</html>