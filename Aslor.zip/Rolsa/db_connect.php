<?php
$servername = "127.0.0.1";
$username = "root"; // Should be root, as per phpMyAdmin configuration
$password = ""; // No password by default
$dbname = "rolsa"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully"; // Test successful connection
?>
