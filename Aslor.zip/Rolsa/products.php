<?php
include 'db_connect.php'; // Include your database connection

$sql = "SELECT id, name, description, price FROM products"; // Adjust table name and fields as necessary
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Rolsa Technologies</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Rolsa Technologies Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="consultation.html">Schedule Consultation</a></li>
                <li><a href="calculator.html">Carbon Footprint Calculator</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h1>Our Products</h1>
        <div class="product-list">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='product'>";
                    echo "<h2>" . htmlspecialchars($row["name"]) . "</h2>";
                    echo "<p>" . htmlspecialchars($row["description"]) . "</p>";
                    echo "<p>Price: $" . htmlspecialchars($row["price"]) . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No products found.</p>";
            }
            $conn->close();
            ?>
        </div>
    </main>
    
    <footer>
        <p>&copy; 2025 Rolsa Technologies</p>
    </footer>
</body>
</html>