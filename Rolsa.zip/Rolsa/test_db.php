<?php
$servername = "localhost"; // or "127.0.0.1"
$username = "root"; // XAMPP default
$password = ""; // XAMPP default (empty)
$dbname = "rolsa"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully to the database.";
$conn->close();
?>