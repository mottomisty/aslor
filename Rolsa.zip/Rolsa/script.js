// Smooth Scrolling and Link Navigation
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const targetId = this.getAttribute('href'); // Get the href value

        // Check if the target is an internal link (starts with #)
        if (targetId.startsWith('#')) {
            e.preventDefault(); // Prevent default link behavior
            const targetElement = document.querySelector(targetId); // Use the href as a selector

            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        } else {
            // For external links, allow the default behavior
            // No need to prevent default
            // Optionally, you can add a smooth scroll effect for internal links
            // but ensure that the links are valid and exist
            // If you want to handle external links, you can just let them work as normal
        }
    });
});

// Back to Top Button
const backToTopButton = document.querySelector('.back-to-top');

window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        backToTopButton.style.display = 'block';
    } else {
        backToTopButton.style.display = 'none';
    }
});

backToTopButton.addEventListener('click', () => {
    const scrollDuration = 800; // Duration of the scroll in milliseconds
    const start = window.scrollY; // Starting position
    const startTime = performance.now(); // Start time

    const animateScroll = (currentTime) => {
        const elapsedTime = currentTime - startTime; // Time elapsed since the start
        const progress = Math.min(elapsedTime / scrollDuration, 1); // Calculate progress (0 to 1)

        // Ease out effect
        const ease = 1 - Math.pow(1 - progress, 3); // Cubic easing function

        // Scroll to the calculated position
        window.scrollTo(0, start * (1 - ease));

        if (progress < 1) {
            requestAnimationFrame(animateScroll); // Continue the animation
        }
    };

    requestAnimationFrame(animateScroll); // Start the animation
});