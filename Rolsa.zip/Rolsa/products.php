<?php
session_start();
include 'db_connect.php'; // Include your database connection

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Fetch products from the database
$stmt = $conn->prepare("SELECT * FROM products");
$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle order submission
    $product_id = $_POST['product_id'];
    $consultation_date = $_POST['consultation_date'];
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

    // Insert order into the database
    $order_stmt = $conn->prepare("INSERT INTO orders (user_id, product_id, consultation_date) VALUES (?, ?, ?)");
    $order_stmt->bind_param("iis", $user_id, $product_id, $consultation_date);
    
    if ($order_stmt->execute()) {
        $message = "Your consultation has been booked successfully!";
    } else {
        $message = "Error: " . $order_stmt->error;
    }
    $order_stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Rolsa Technologies</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js"></script>
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Rolsa Technologies Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h1>Our Products</h1>
        <?php if ($message) echo "<p class='error-message'>$message</p>"; ?>
        <div class="product-grid">
            <?php foreach ($products as $product): ?>
                <div class="product-item">
                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p><?php echo htmlspecialchars($product['description']); ?></p>
                    <a href="<?php echo htmlspecialchars($product['url']); ?>" class="learn-more">Learn More</a>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
    
    <footer>
        <p>&copy; 2025 Rolsa Technologies</p>
        <p>123 Greenway Drive, Eco City, EC 12345</p>
        <p>Phone: (123) 456-7890</p>
        <p>Email: contact@rolsatechnologies.com</p>
    </footer>
</body>
</html>