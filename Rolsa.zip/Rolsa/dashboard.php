<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Rolsa Technologies</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js"></script>
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Rolsa Technologies Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section>
            <h2>Welcome Back, <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User '; ?>!</h2>
            <p>Hello, <?php echo htmlspecialchars($_SESSION['email']); ?>! Here you can manage your account and view your orders.</p>
            <h3>Your Orders</h3>
            <p>You have no orders yet.</p>
            <!-- You can add more functionality here, like displaying user orders -->
        </section>
    </main>
    
    <footer>
        <p>&copy; 2025 Rolsa Technologies</p>
        <p>123 Greenway Drive, Eco City, EC 12345</p>
        <p>Phone: (123) 456-7890</p>
        <p>Email: contact@rolsatechnologies.com</p>
    </footer>
</body>
</html>