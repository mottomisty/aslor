<?php
session_start();
include 'db_connect.php'; // Include your database connection

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute
    $stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_password);
        $stmt->fetch();
        if (password_verify($password, $db_password)) {
            $_SESSION['email'] = $email; // Store email in session
            header("Location: dashboard.php"); // Redirect to a dashboard or home page
            exit();
        } else {
            $message = "Incorrect password.";
        }
    } else {
        $message = "Email not found.";
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Rolsa Technologies</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Rolsa Technologies Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <div class="login-container">
            <h1>Login</h1>
            <form method="POST" action="">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <?php if ($message) echo "<p class='error-message'>$message</p>"; ?>
            <div class="social-login">
                <p>Or sign in with:</p>
                <button class="google-btn">Google</button>
                <button class="facebook-btn">Facebook</button>
            </div>
        </div>
    </main>
    
    <footer>
    <p>&copy; 2025 Rolsa Technologies</p>
    <p>123 Greenway Drive, Eco City, EC 12345</p>
    <p>Phone: (123) 456-7890</p>
    <p>Email: contact@rolsatechnologies.com</p>
    <div class="social-media-icons">
        <a href="https://www.instagram.com" target="_blank" aria-label="Instagram">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="https://www.facebook.com" target="_blank" aria-label="Facebook">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="https://www.x.com" target="_blank" aria-label="X">
            <i class="fab fa-x"></i>
        </a>
    </div>
</footer>
</body>
</html>